import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class AddSiteTextFormField extends StatefulWidget {
  const AddSiteTextFormField({Key? key}) : super(key: key);

  @override
  State<AddSiteTextFormField> createState() => _AddSiteTextFormFieldState();
}

class _AddSiteTextFormFieldState extends State<AddSiteTextFormField> {
  @override
  Widget build(BuildContext context) {
    return TextFormField(
        // decoration: InputDecoration(
        //     filled: true,
        //     fillColor: Color.fromRGBO(245, 247, 251, 1),
        //     border: OutlineInputBorder(
        //       borderSide: BorderSide(
        //         width: 1,
        //         color: Color.fromRGBO(235, 235, 235, 1),
        //       ),
        //       borderRadius: BorderRadius.circular(5),
        //     ),
        //     enabledBorder: OutlineInputBorder(
        //       borderSide: BorderSide(
        //         width: 1,
        //         color: Color.fromRGBO(235, 235, 235, 1),
        //       ),
        //     ),
        //     hintText: ""),
        );
  }
}
