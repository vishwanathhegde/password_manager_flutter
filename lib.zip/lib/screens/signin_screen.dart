import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:passwordmanager/utilities/validation_textfield.dart';
import 'package:passwordmanager/utilities/validator.dart';
import '../utilities/theme_data.dart';
import 'home_screen.dart';
import 'package:passwordmanager/utilities/custom_button.dart';

class SignIn extends StatefulWidget {
  const SignIn({Key? key}) : super(key: key);

  @override
  State<SignIn> createState() => _SignInState();
}

class _SignInState extends State<SignIn> with MobileValidation {
  @override
  final formKey = GlobalKey<FormState>();
  Widget build(BuildContext context) {
    return Form(
      key: formKey,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          MyTextField(
              label: "Mobile Number",
              callBack: (value) {
                return mobileValadition(value);
              }),
          MyTextField(
              label: "MPin",
              callBack: (value) {
                return passwordValidator(value);
              }),
          CustomWhiteButton(
              text: "Log In",
              onPressed: () {
                if (formKey.currentState!.validate()) {
                  Navigator.of(context).push(MaterialPageRoute(
                      builder: (context) => const HomeScreen()));
                }
              })
        ],
      ),
    );
  }
}
