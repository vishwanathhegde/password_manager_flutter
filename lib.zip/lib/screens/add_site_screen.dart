import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import '../utilities/add_site_textfield.dart';
import 'package:dropdown_textfield/dropdown_textfield.dart';

class AddSite extends StatefulWidget {
  const AddSite({Key? key}) : super(key: key);

  @override
  State<AddSite> createState() => _AddSiteState();
}

class _AddSiteState extends State<AddSite> {
  @override
  final formKey = GlobalKey<FormState>();
  FocusNode searchFocusNode = FocusNode();
  FocusNode textFieldFocusNode = FocusNode();
  late SingleValueDropDownController _cnt;
  late MultiValueDropDownController _cntMulti;
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Add Site"),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          child: Form(
            key: formKey,
            child: Container(
              margin: EdgeInsets.only(left: 20, right: 20),
              // color: Colors.red,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SizedBox(
                    height: MediaQuery.of(context).size.height * .03,
                  ),
                  Text(
                    "URL",
                    style: TextStyle(color: Colors.black26),
                  ),
                  SizedBox(
                    height: MediaQuery.of(context).size.height * .02,
                  ),
                  TextFormField(),
                  SizedBox(
                    height: MediaQuery.of(context).size.height * .02,
                  ),
                  Text(
                    "Site Name",
                    style: TextStyle(color: Colors.black26),
                  ),
                  SizedBox(
                    height: MediaQuery.of(context).size.height * .02,
                  ),
                  TextFormField(),
                  SizedBox(
                    height: MediaQuery.of(context).size.height * .02,
                  ),
                  Text(
                    "Sector/Folder",
                    style: TextStyle(color: Colors.black26),
                  ),
                  SizedBox(
                    height: MediaQuery.of(context).size.height * .02,
                  ),
                  DropDownTextField(
                    listSpace: 5,
                    listPadding: ListPadding(top: 20),
                    enableSearch: false,
                    validator: (value) {
                      if (value == null) {
                        return "Required field";
                      } else {
                        return null;
                      }
                    },
                    dropDownList: const [
                      DropDownValueModel(name: 'Social media', value: "value1"),
                      DropDownValueModel(name: 'Bank', value: "value2"),
                      DropDownValueModel(name: 'Personal', value: "value3"),
                      DropDownValueModel(name: 'E-Commerce', value: "value4"),
                      DropDownValueModel(name: 'Others', value: "value5"),
                    ],
                    dropDownItemCount: 5,
                    onChanged: (val) {},
                  ),
                  SizedBox(
                    height: MediaQuery.of(context).size.height * .02,
                  ),
                  Text(
                    "Social Media",
                    style: TextStyle(color: Colors.black26),
                  ),
                  SizedBox(
                    height: MediaQuery.of(context).size.height * .02,
                  ),
                  DropDownTextField(
                    listSpace: 5,
                    listPadding: ListPadding(top: 20),
                    enableSearch: false,
                    validator: (value) {
                      if (value == null) {
                        return "Required field";
                      } else {
                        return null;
                      }
                    },
                    dropDownList: const [
                      DropDownValueModel(name: 'Facebook', value: "value1"),
                      DropDownValueModel(name: 'Instagram', value: "value2"),
                      DropDownValueModel(name: 'Youtube', value: "value3"),
                      DropDownValueModel(name: 'Twitter', value: "value4"),
                      DropDownValueModel(name: 'Pintrest', value: "value5"),
                    ],
                    dropDownItemCount: 5,
                    onChanged: (val) {},
                  ),
                  SizedBox(
                    height: MediaQuery.of(context).size.height * .02,
                  ),
                  Text(
                    "User Name",
                    style: TextStyle(color: Colors.black26),
                  ),
                  SizedBox(
                    height: MediaQuery.of(context).size.height * .02,
                  ),
                  TextFormField(),
                  SizedBox(
                    height: MediaQuery.of(context).size.height * .02,
                  ),
                  Text(
                    "Site Password",
                    style: TextStyle(color: Colors.black26),
                  ),
                  SizedBox(
                    height: MediaQuery.of(context).size.height * .02,
                  ),
                  TextFormField(
                    decoration:
                        InputDecoration(suffixIcon: Icon(Icons.remove_red_eye)),
                  ),
                  SizedBox(
                    height: MediaQuery.of(context).size.height * .02,
                  ),
                  Text(
                    "Notes",
                    style: TextStyle(color: Colors.black26),
                  ),
                  SizedBox(
                    height: MediaQuery.of(context).size.height * .02,
                  ),
                  TextFormField(),
                  SizedBox(
                    height: MediaQuery.of(context).size.height * .02,
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
