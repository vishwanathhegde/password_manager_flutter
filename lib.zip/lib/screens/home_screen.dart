import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'add_site_screen.dart';
import 'package:passwordmanager/utilities/custom_card.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Image.asset('images/pass_manager.png'),
        backgroundColor: const Color(0xFF0E85FF),
        elevation: 10,
        // leadingWidth: 30,
        leading: Image.asset('images/burger_menu.png'),
        actions: [
          Image.asset('images/search.png'),
          Image.asset('images/sync_icn.png'),
          Image.asset('images/profile.png'),
        ],
      ),
      body: Container(
        padding: EdgeInsets.all(20),
        child: Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Padding(
                  padding: const EdgeInsets.all(20),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'Sites',
                        style: TextStyle(
                            fontWeight: FontWeight.bold,
                            color: Color(0xFF3C4857),
                            fontSize: 30),
                      ),
                      Container(
                        height: 4,
                        width: 40,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(5),
                          color: const Color(0xFFFFA222),
                        ),
                      ),
                    ],
                  ),
                ),
                Row(
                  children: [
                    const Text(
                      'Social Media',
                      style: TextStyle(
                        fontWeight: FontWeight.normal,
                        color: Color(0xFF3C4857),
                        fontSize: 20,
                      ),
                    ),
                    const SizedBox(
                      width: 10,
                    ),
                    Container(
                      height: 30,
                      width: 30,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(15),
                        color: const Color(0xFF0E85FF),
                      ),
                      child: const Center(
                        child: Text(
                          '07',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 17.5,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(
                      width: 10,
                    ),
                    GestureDetector(
                        onTap: () {
                          print('Drop Down Button clicked');
                        },
                        child: Image.asset('images/bottom_arrow.png')),
                  ],
                ),
              ],
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.of(context)
              .push(MaterialPageRoute(builder: (context) => const AddSite()));
        },
        child: const Icon(Icons.add),
      ),
    );
  }
}
