import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:passwordmanager/utilities/custom_button.dart';
import 'package:passwordmanager/utilities/validator.dart';

import '../utilities/validation_textfield.dart';
import 'home_screen.dart';

class SignUp extends StatefulWidget {
  const SignUp({Key? key}) : super(key: key);

  @override
  State<SignUp> createState() => _SignUpState();
}

class _SignUpState extends State<SignUp> with MobileValidation {
  final formKey = GlobalKey<FormState>();
  @override
  Widget build(BuildContext context) {
    return Form(
      key: formKey,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          MyTextField(
              label: "Mobile Number",
              callBack: (value) {
                return mobileValadition(value);
              }),
          MyTextField(
              label: "MPin",
              callBack: (value) {
                return passwordValidator(value);
              }),
          MyTextField(
              label: "MPin",
              callBack: (value) {
                return passwordValidator(value);
              }),
          CustomWhiteButton(
              text: "Sign Up",
              onPressed: () {
                Navigator.of(context).push(MaterialPageRoute(
                    builder: (context) => const HomeScreen()));
              }),
        ],
      ),
    );
    ;
  }
}
